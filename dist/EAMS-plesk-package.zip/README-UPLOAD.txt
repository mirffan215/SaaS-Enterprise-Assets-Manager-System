EAMS - upload package for Plesk (web access only)

1. Plesk > Websites & Domains > your site > File Manager > httpdocs: delete the default files, upload THIS zip, "Extract" it there.
2. In httpdocs rename  appsettings.Production.json.example  to  appsettings.Production.json  and edit it (database connection, setup key).
3. Open https://<your site>/  - it leads to the setup page. Enter the setup key and your first company.
4. Edit appsettings.Production.json again and delete the "Setup" section.

Full guide: docs/Plesk-Hosting.md in the repository (also sent with this package).
Updating later: upload and extract a newer package over the old one. Keep appsettings.Production.json and the App_Data folder.
